package com.example.notepad.service;

import com.example.notepad.model.Note;
import com.example.notepad.repo.NoteRepository;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Service
public class NoteService {

    private final NoteRepository repo;
    private final Clock clock;
    private final SanitizerService sanitizer;

    public NoteService(NoteRepository repo, SanitizerService sanitizer, Clock clock) {
        this.repo = repo;
        this.sanitizer = sanitizer;
        this.clock = clock;
    }

    public List<Note> list() {
        return repo.findAll();
    }

    public Optional<Note> get(Long id) {
        return repo.findById(id);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    public Optional<Note> findByShareKey(String key) {
        return repo.findByShareKey(key);
    }
    
    public record PageResult<T>(java.util.List<T> items, long total) {}

    public PageResult<Note> find(String q, Note.Priority prio, int page, int size) {
        var all = repo.findAll();

        var filtered = all.stream()
                .filter(n -> q == null 
                        (n.getTitle() != null &&
                         n.getTitle().toLowerCase().contains(q.toLowerCase())))
                .filter(n -> prio == null  n.getPriority() == prio)
                .toList();

        int from = Math.max(0, page * size);
        int to = Math.min(filtered.size(), from + size);
        var slice = (from >= filtered.size()) ? java.util.List.<Note>of() : filtered.subList(from, to);

        return new PageResult<>(slice, filtered.size());
    }

    public Note create(String title, String content, Note.Priority priority) {
        title = title == null ? "" : title.trim();
        content = sanitizer.clean(content);
        Note n = new Note(null, title, content, java.time.Instant.now(clock));
        n.setPriority(priority);
        return repo.save(n);
    }

    public Note update(Long id, String title, String content, Note.Priority priority) {
        var n = repo.findById(id).orElseThrow();
        n.setTitle(title == null ? "" : title.trim());
        n.setContent(sanitizer.clean(content));
        n.setPriority(priority);
        return repo.save(n);
    }
}