package com.example.notepad.web;

import com.example.notepad.dto.NoteRequest;
import com.example.notepad.dto.NoteResponse;
import com.example.notepad.model.Note;
import com.example.notepad.service.NoteService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/notes")
@Tag(name = "Notes API", description = "CRUD, фільтрація, пагінація, часткове оновлення")
public class NoteRestController {

    private final NoteService service;
    private final ObjectMapper mapper;

    public NoteRestController(NoteService service, ObjectMapper mapper) {
        this.service = service;
        this.mapper = mapper;
    }

    @Operation(summary = "Створити нотатку")
    @PostMapping
    public ResponseEntity<NoteResponse> create(@RequestBody NoteRequest req) {
        Note n = service.create(req.title, req.content, req.priority);
        return ResponseEntity.status(HttpStatus.CREATED).body(NoteResponse.from(n));
    }

    @Operation(summary = "Отримати нотатку за id")
    @GetMapping("/{id}")
    public ResponseEntity<NoteResponse> get(@PathVariable Long id) {
        return service.get(id)
                .map(n -> ResponseEntity.ok(NoteResponse.from(n)))
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    @Operation(summary = "Список нотаток з фільтрами та пагінацією")
    @GetMapping
    public ResponseEntity<List<NoteResponse>> list(
            @RequestParam(required = false) String q,
            @RequestParam(required = false) Note.Priority priority,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        var pg = service.find(q, priority, page, size);
        // якщо у тебе Java 11 — заміни .toList() на .collect(Collectors.toList())
        var body = pg.items().stream().map(NoteResponse::from).toList();

        return ResponseEntity.ok()
                .header("X-Total-Count", String.valueOf(pg.total()))
                .header("X-Page", String.valueOf(page))
                .header("X-Size", String.valueOf(size))
                .body(body);
    }

    @Operation(summary = "Оновити нотатку (повністю)")
    @PutMapping("/{id}")
    public ResponseEntity<NoteResponse> update(@PathVariable Long id, @RequestBody NoteRequest req) {
        var saved = service.update(id, req.title, req.content, req.priority);
        return ResponseEntity.ok(NoteResponse.from(saved));
    }

    @Operation(summary = "Часткове оновлення (JSON Patch, RFC 6902)")
    @PatchMapping(path = "/{id}", consumes = "application/json-patch+json")
    public ResponseEntity<NoteResponse> patch(@PathVariable Long id, @RequestBody JsonNode patchNode) throws IOException {
        var opt = service.get(id);
        if (opt.isEmpty()) return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        var existing = opt.get();
        try {
            // 1) JsonNode -> JsonPatch (самостійно, щоб не впиратись у конвертер)
            JsonPatch patch = JsonPatch.fromJson(patchNode);
            // 2) Note -> JsonNode
            JsonNode target = mapper.valueToTree(existing);
            // 3) apply
            JsonNode patched = patch.apply(target);
            // 4) JsonNode -> DTO -> update
            NoteRequest req = mapper.treeToValue(patched, NoteRequest.class);
            var saved = service.update(id, req.title, req.content, req.priority);
            return ResponseEntity.ok(NoteResponse.from(saved));
        } catch (JsonPatchException | JsonProcessingException e) {
            return ResponseEntity.badRequest().build(); // 400 якщо патч/дані криві
        }
    }
    @Operation(summary = "Видалити нотатку")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (service.get(id).isEmpty()) return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}